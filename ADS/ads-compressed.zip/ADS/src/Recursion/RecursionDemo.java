package Recursion;

public class RecursionDemo {
	
	static void fun(int n)
	{
		if(n > 5)
			return;
		
		System.out.println(n);
		
		fun(n + 1);
		return;
	}
	
	public static void main(String[] args) {
		
		fun(1);
	}
}

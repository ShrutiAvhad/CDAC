package sorting;

public class Sorting {

	private static void BubbleSort(int arr[], int s) {
		
		int i, j, t, flag;
		
		for(i = arr.length-1; i > 0; i--)
		{
			flag = 0;
			
			for(j = 0; j < i; j++)
			{
				if(arr[j] > arr[j + 1])
				{
					t = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] =t;
					flag = 1;
				}
			}
			if(flag == 0)
				break;
		}
	}
	
	private static void SelectionSort(int[] arr) {
		
		int i, j, min, t;
		for(i = 0; i < arr.length; i++)
		{
			min = i;
			
			for(j = i + 1; j < arr.length-1;j++)
			{
				if(arr[j] < arr[min])
					min = j;
			}
			
			if(min != i)
			{
				t = arr[i];
				arr[i] = arr[min];
				arr[min] = t;
			}
		}
		
	}
	
	private static void InsertSort(int arr[]) {
		
		int i, j, k;
		
		for(i = 1; i < arr.length; i++)
		{
			k = arr[i];
			
			for(j = i-1; j >= 0 && k < arr[j]; j--)
			{
				arr[j + 1] = arr[j];
			}
			
			arr[j + 1] = k;
		}
		
	}

	private static void Merge_ver1(int tar[], int arr1[], int arr2[]) {
		
		int i = 0, j = 0, k = 0;
		while((i < arr1.length) && (j < arr2.length))
		{
			if(arr1[i] < arr2[j])
			{
				tar[k] = arr1[i];
				i++; k++;
			}
			else if(arr1[i] > arr2[j])
			{
				tar[k] = arr2[j];
				j++; k++;
			}
			else
			{
				tar[k] = arr1[i];
				i++;j++; k++;
			}
		}
		
		while(i < arr1.length)
		{
			tar[k] = arr1[i];
			i++; k++;
		}
		
		while(j < arr2.length)
		{
			tar[k] = arr2[j];
			j++;k++;
		}
		
	}
	
	
	public static void main(String[] args) {
		

		System.out.println("\nBubble Sort : ");
		int arr[] = {5, 2, 9, 1, 3};
		BubbleSort(arr, arr.length);

		for(int i = 0; i < arr.length; i++)
		{
		    System.out.print(arr[i] + " ");
		}
		
		System.out.println("\n======================================\n");
		int arr1[] = {3, 5, 80, 58, 12, 40};
		System.out.println("Selection Sort : ");
		SelectionSort(arr1);
		for(int i = 0; i < arr1.length; i++)
		{
		    System.out.print(arr1[i] + " ");
		}
		
		System.out.println("\n======================================\n");
		System.out.println("Insertion Sort : ");
		InsertSort(arr1);
		for(int i = 0; i < arr1.length; i++)
		{
		    System.out.print(arr1[i] + " ");
		}
		
		System.out.println("\n======================================\n");
		System.out.println("Merge Sort Version 1 : ");
		Merge_ver1(arr1, arr1, arr1);
		for(int i = 0; i < arr1.length; i++)
		{
		    System.out.print(arr1[i] + " ");
		}
	}

	
}

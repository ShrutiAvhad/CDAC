<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    

<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Book List</title>
</head>
<body>
	<h2>Books List</h2>
	<table boarder="1">
	
	<tr>
		<th>Id</th>
		<th>Title</th>
		<th>Author</th>
		<th>Category</th>
		<th>Status</th>	
		<th>Action</th>	
	</tr>
	
	<c:forEach var="book" items="${books}">
	
	<tr>
		<td>${book.bookId}</td>
		<td>${book.title}</td>
		<td>${book.author}</td>
		<td>${book.category}</td>
		
		<td>
		
		<a href = "issueBook?id=${book.bookId}">Issue</a>
		<a href = "returnBook?id=${book.bookId}">Return</a>
		</td>
		
	</tr>
	</c:forEach>
	</table>
</body>
</html>
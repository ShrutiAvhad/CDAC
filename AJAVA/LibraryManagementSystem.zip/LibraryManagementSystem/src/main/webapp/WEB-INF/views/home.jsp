<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Library</title>
</head>
<body>
	<h2>Library Management System</h2>
	
	<a href="showForm">Add Book</a><br>
	
	<a href="books">View Books</a>
</body>
</html>
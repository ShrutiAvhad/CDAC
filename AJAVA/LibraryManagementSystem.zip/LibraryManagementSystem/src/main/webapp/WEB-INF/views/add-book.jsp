<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
    
<%@ taglib prefix = "form"  uri="http://www.springframework.org/tags/form"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Add Book</title>
</head>
<body>
	<h2>Add Book</h2>
	
	<form:form action="addBook" method="post" modelAttribute="book">
	
	Book Id:
	<form:input path="bookId"/>
	
	Title:
	<form:input path="title"/>
	
	Author:
	<form:input path="author"/>
	
	Category:
	<form:input path="category"/>
	
	<form:button><input type="submit" value="Add Book"/></form:button>
	
	
	</form:form>
</body>
</html>
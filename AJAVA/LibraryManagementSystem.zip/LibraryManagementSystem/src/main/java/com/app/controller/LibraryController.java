package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.model.Book;
import com.app.service.LibraryService;

@Controller
public class LibraryController {
	
	@Autowired
	private LibraryService service;
	
	@RequestMapping("/")
	public String home()
	{
		return "home";
	}
	
	@RequestMapping("/showForm")
	public String showForm(Model model)
	{
		model.addAttribute("book", new Book());
		return "add-book";
	}
	
	@PostMapping("/addBook")
	public String addBook(@ModelAttribute("book") Book book)
	{
		service.addBook(book);
		return "redirect:/books";
	}
	
	@RequestMapping("/books")
	public String viewBooks(Model model)
	{
		model.addAttribute("books", service.getAllBooks());
		return "book-list";
	}
	
	@RequestMapping("/issueBook")
	public String issueBook(@RequestParam("id") int id)
	{
		service.issueBook(id);
		return "redirect:/books";
	}
	
	@RequestMapping("/returnBook")
	public String returnBook(@RequestParam("id") int id)
	{
		service.returnBook(id);
		return "redirect:/books";
	}
}

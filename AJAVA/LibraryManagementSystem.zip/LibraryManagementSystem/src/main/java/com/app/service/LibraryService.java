package com.app.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.app.model.Book;

@Service
public class LibraryService {
	
	private List<Book> bookList = new ArrayList<>();
	
	public void addBook(Book book)
	{
		bookList.add(book);
	}
	
	public List<Book> getAllBooks()
	{
		return bookList;
	}
	
	public void issueBook(int id)
	{
		for(Book b : bookList)
		{
			if(b.getId() == id)
			{
				b.setAvailable(false);
			}
		}
	}
	
	public void returnBook(int id)
	{
		for(Book b : bookList)
		{
			if(b.getId() == id)
			{
				b.setAvailable(true);
			}
		}
	}
}
